Sample configurations for your convenience:

Once you have specified the design root in the app:
1. Put images-resource under:
<Your run directory>/Design-Resources/
This is also where you would see a "cfg" directory.
You can use this to double check the location.

2. Copy "styles" to:
<Your design root>/Website/
You can also open the stylesheet.css and stylesheet-mobile.css, and copy the content to the Style & Mobile Style setup in the app. But the lightbox folder can only be placed manually at the moment.

3. Copy Framework.txt, Framework-mobile.txt, Website_Name.txt, and Website_URL.txt to:
<Your design root>/Resource/
You can also open the files and copy the content into the setups in the app.